package br.com.fiap.biblioteca.dominio;

public class Correios {

    public void adicionarEndereco(Aluno aluno){

    }
}
