package br.com.fiap.biblioteca.infra.dao;

import br.com.fiap.biblioteca.dominio.Aluno;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class AlunoDAO {
    private Connection conexao = null;
    public AlunoDAO()  {
        conexao = new ConnectionFactory().getConnection();
    }



    public void fecharConexao(){
        try {
            conexao.close();
        }catch (SQLException e){
            throw new RuntimeException(e);
        }

    }
    public void inserirAlunos(Aluno aluno){
        String insercaoAlunos = "INSERT INTO ALUNOS(nome, chamada, turma) VALUES(?,?,?)";
        try{
            PreparedStatement preparacaoInsercao = conexao.prepareStatement(insercaoAlunos);

            preparacaoInsercao.setString(1,aluno.getNome());
            preparacaoInsercao.setString(2,aluno.getChamada());
            preparacaoInsercao.setString(3,aluno.getTurma());
            preparacaoInsercao.execute();
            preparacaoInsercao.close();
            System.out.println("Aluno inserido com sucesso!");

        }catch(SQLException e){
            throw new RuntimeException(e);
        }
    }
    public ArrayList<Aluno> listarAlunosTurma(String turma){
        ArrayList<Aluno> alunosPorTurma = new ArrayList<>();

        String consultaAlunoPorTurma = "SELECT * FROM ALUNOS WHERE turma = ?";

        try {
            Scanner scanner = new Scanner(System.in);
            PreparedStatement preparandoConsulta = conexao.prepareStatement(consultaAlunoPorTurma);
            preparandoConsulta.setString(1,turma);
            ResultSet resultSet = preparandoConsulta.executeQuery();
            while(resultSet.next()){
                Aluno aluno = new Aluno();
                aluno.setNome(resultSet.getString("nome"));
                aluno.setChamada(resultSet.getString("chamada"));
                aluno.setTurma(resultSet.getString("turma"));
                alunosPorTurma.add(aluno);
            }
        }catch (SQLException e){
            throw new RuntimeException(e);
        }
        return alunosPorTurma;
    }
    public ArrayList<Aluno> listarAlunosTurmaEChamada(String turma, String chamada){
        ArrayList<Aluno> alunosPorTurma = new ArrayList<>();

        String consultaAlunoPorTurma = "SELECT * FROM ALUNOS WHERE turma = ? AND chamada = ?";

        try {
            Scanner scanner = new Scanner(System.in);
            PreparedStatement preparandoConsulta = conexao.prepareStatement(consultaAlunoPorTurma);
            preparandoConsulta.setString(1,turma);
            preparandoConsulta.setString(2,chamada);
            ResultSet resultSet = preparandoConsulta.executeQuery();
            while(resultSet.next()){
                Aluno aluno = new Aluno();
                aluno.setNome(resultSet.getString("nome"));
                aluno.setChamada(resultSet.getString("chamada"));
                aluno.setTurma(resultSet.getString("turma"));
                alunosPorTurma.add(aluno);
            }
        }catch (SQLException e){
            throw new RuntimeException(e);
        }
        return alunosPorTurma;
    }



}
