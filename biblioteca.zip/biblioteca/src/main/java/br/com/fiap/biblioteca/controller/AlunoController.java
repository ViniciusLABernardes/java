package br.com.fiap.biblioteca.controller;

import br.com.fiap.biblioteca.dominio.Aluno;
import br.com.fiap.biblioteca.infra.dao.AlunoDAO;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;

@Path("alunos")
public class AlunoController {

    // complete essa classe com os métodos, atributos e anotações necessárias.
    private AlunoDAO alunoDAO = new AlunoDAO();
    public Response adicionar(Aluno aluno){
        return null; // remova essa linha quando for trabalhar com esse método
    }


    @GET
    @Path("/{turma}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response buscarPorTurma(@PathParam("turma") String turma) {

        ArrayList<Aluno> alunos = alunoDAO.listarAlunosTurma("1TDSPY");

        return Response.status(Response.Status.OK).entity(alunos).build();
    }
    @GET
    @Path("/{turma}/{chamada}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response buscarPorTurmaEChamada(
            @PathParam("turma") String turma,
            @PathParam("chamada") String chamada) {
        ArrayList<Aluno> alunos = alunoDAO.listarAlunosTurmaEChamada("1tdspy","543210");
        return Response.status(Response.Status.OK).entity(alunos).build();
    }
}
