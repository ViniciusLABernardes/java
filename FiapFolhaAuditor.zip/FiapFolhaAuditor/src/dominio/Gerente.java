package dominio;

import java.time.LocalDate;

public class Gerente extends Funcionario implements PessoaAutenticavel, Mensalista{
	double bonus;
	Gerente(double salario, String chapa, LocalDate dataAdmissao, double bonus){
		super(salario, chapa, dataAdmissao);
		this.bonus = bonus;
	}

	public boolean autenticar() {
		return true;
	}
	public double calcularMensalistas() {
		return getSalario();
	}

}
