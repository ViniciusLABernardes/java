package dominio;

import java.time.LocalDate;

public abstract class Funcionario {
	private double salario;
	private String chapa;
	private LocalDate dataAdmissao;
	
	public Funcionario(double salario, String chapa, LocalDate dataAdmissao)
	{
		this.salario = salario;
		this.chapa = chapa;
		this.dataAdmissao = dataAdmissao;
	}
	public double getSalario() {
		return this.salario;
	}
}

