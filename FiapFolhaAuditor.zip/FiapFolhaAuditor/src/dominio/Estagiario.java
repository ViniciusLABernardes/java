package dominio;

import java.time.LocalDate;

public class Estagiario extends Funcionario implements Mensalista{
	private double valeTransporte;
	public Estagiario(double salario, String chapa, LocalDate dataAdmissao, double valeTransporte) {
			super(salario, chapa, dataAdmissao);
			this.valeTransporte = valeTransporte;
	}
	
	public double calcularMensalistas() {
		return getSalario();
	}
}
