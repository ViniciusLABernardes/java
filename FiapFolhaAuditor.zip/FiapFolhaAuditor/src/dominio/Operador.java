package dominio;

import java.time.LocalDate;

public class Operador extends Funcionario implements Horista{
	public Operador(double salario, String chapa, LocalDate dataAdmissao)
	{
		super(salario, chapa, dataAdmissao);
	}
	public double calculoSalarioHoristas() {
		return getSalario() ;
	}
}
