package dominio;

public interface Mensalista {
	
	public double calcularMensalistas();
}
