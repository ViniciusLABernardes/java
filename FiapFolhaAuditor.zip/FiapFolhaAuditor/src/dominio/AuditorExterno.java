package dominio;

public class AuditorExterno implements PessoaAutenticavel{

		public boolean autenticar() {
			return true;
		}
}
