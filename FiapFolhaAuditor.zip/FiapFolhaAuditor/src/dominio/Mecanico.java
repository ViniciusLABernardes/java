package dominio;

import java.time.LocalDate;

public class Mecanico extends Funcionario implements Horista{
	double plr;
	public Mecanico(double salario, String chapa, LocalDate dataAdmissao, double plr) {
		super(salario, chapa, dataAdmissao);
		this.plr = plr;
	}
	public double getSalario() {
		return getSalario();
	}
	public double calculoSalarioHoristas() {
		return getSalario() ;
	}
}
