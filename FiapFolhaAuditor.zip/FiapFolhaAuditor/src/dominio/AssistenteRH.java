package dominio;

import java.time.LocalDate;

public class AssistenteRH extends Funcionario implements PessoaAutenticavel, Mensalista{
	private double porcentagemComissao;
	public AssistenteRH(double salario, String chapa, LocalDate dataAdmissao, double porcentagemComissao) {
		super(salario, chapa, dataAdmissao);
		this.porcentagemComissao = porcentagemComissao;
		
	}
	public boolean autenticar() {
		return true;
	}
	public double calcularMensalistas() {
		return getSalario();
	}
}
