package dominio;

public interface PessoaAutenticavel {
	
	public boolean autenticar();

}
