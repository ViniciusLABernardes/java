package dominio;

public interface Horista {
	
	public double calculoSalarioHoristas();
}
