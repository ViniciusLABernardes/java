package dominio;

import java.util.ArrayList;
import java.time.LocalDate;

public class Main {
	public static void main(String[] args) {
		
		Operador joao = new Operador(2000, "5355x", LocalDate.now());
		Operador cleber = new Operador(5000, "555x", LocalDate.now());
		
		ArrayList<Horista> funcionariosH = new ArrayList<>();
		
		funcionariosH.add(cleber);
		funcionariosH.add(joao);
		
		AuditorExterno roberto = new AuditorExterno();
		
		Gerente antonio = new Gerente(6000, "444d", LocalDate.now(), 500);
		Estagiario carlos = new Estagiario(2000, "44ff", LocalDate.now(), 600);
		
		ArrayList<Mensalista> funcionariosM = new ArrayList<>();
		
		
		funcionariosM.add(carlos);
		funcionariosM.add(antonio);
		
		Autenticadora a = new Autenticadora();
		a.autentica(roberto);
		
		double somaMensalista = 0;
			for (Mensalista m: funcionariosM) {
				somaMensalista += m.calcularMensalistas();
			}
			System.out.println("mensalistas " +somaMensalista);
			
			double somaHorista = 0;
			
			for (Horista h: funcionariosH) {

				somaHorista += h.calculoSalarioHoristas();
			}
			System.out.println("horistas " + somaHorista);
			
		
	}
}
