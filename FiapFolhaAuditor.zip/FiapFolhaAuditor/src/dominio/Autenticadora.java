package dominio;

public class Autenticadora {
	
	public void autentica(PessoaAutenticavel pessoa) {
		//implementacao a vontade
		pessoa.autenticar();
	}
}
