package dominio;

import java.util.ArrayList;

public class Gerente extends Funcionario{
    private int quantidadeFuncionarios;
    protected ArrayList<Funcionario> funcionarios;
    public Gerente(String nome, String cpf, double salario, ArrayList<Funcionario> funcionarios){
        super(nome, cpf, salario);
        this.quantidadeFuncionarios = funcionarios.size();
        this.funcionarios = funcionarios;
    }

    public double lerBonificacao(){
        return salario * 0.15;
    }

    public ArrayList<Funcionario> getFuncionarios() {
        return funcionarios;
    }
}
