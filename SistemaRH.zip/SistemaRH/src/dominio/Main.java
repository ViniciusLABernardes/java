package dominio;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Funcionario fun1 = new Funcionario("jair", "12345678909", 2500);
        Funcionario fun2 = new Funcionario("bruno", "98765432101", 2800);
        Funcionario fun3 = new Funcionario("mario", "98765435678", 3200);

        ArrayList<Funcionario> grupoFuncionarios1 = new ArrayList<>();
        grupoFuncionarios1.add(fun1);
        grupoFuncionarios1.add(fun2);
        grupoFuncionarios1.add(fun3);

        Funcionario fun4 = new Funcionario("maria", "12345678909", 1900);
        Funcionario fun5 = new Funcionario("joao", "98765432101", 2400);
        Funcionario fun6 = new Funcionario("roberto", "98765435678", 2250);

        ArrayList<Funcionario> grupoFuncionarios2 = new ArrayList<>();
        grupoFuncionarios2.add(fun4);
        grupoFuncionarios2.add(fun5);
        grupoFuncionarios2.add(fun6);

        Funcionario fun7 = new Funcionario("vinicius", "12345678909", 4000);
        Funcionario fun8 = new Funcionario("david", "12345678909", 4200);
        Funcionario fun9 = new Funcionario("vitor", "12345678909", 5000);

        ArrayList<Funcionario> grupoFuncionarios3 = new ArrayList<>();
        grupoFuncionarios3.add(fun7);
        grupoFuncionarios3.add(fun8);
        grupoFuncionarios3.add(fun9);


        Gerente gerente1 = new Gerente("alberto", "12345645609", 7600,  grupoFuncionarios1);
        Gerente gerente2 = new Gerente("sabrina", "78956797602", 7600,  grupoFuncionarios2);
        Gerente gerente3 = new Gerente("heitor", "78956797602", 9600,  grupoFuncionarios3);

        ArrayList<Gerente> gerentes = new ArrayList<>();
        gerentes.add(gerente1);
        gerentes.add(gerente2);
        gerentes.add(gerente3);

        for(Gerente g : gerentes){
            System.out.println(g.nome + '\n' + g.salario  + '\n' + g.lerBonificacao() + "  \n funcionarios: \n"
            );
            for(Funcionario umFuncionario : g.getFuncionarios()){
                System.out.println(umFuncionario.exibir());
            }
        }


    }



}

