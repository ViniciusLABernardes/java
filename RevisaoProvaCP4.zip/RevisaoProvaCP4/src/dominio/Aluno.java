package dominio;

import java.time.LocalDate;

public class Aluno {
    private String nome;
    private String cpf;
    private LocalDate dataNasc;
        public Aluno(String nome, String cpf, LocalDate dataNasc){
            this.nome = nome;
            this.cpf = cpf;
            this.dataNasc = dataNasc;
        }
        public Aluno(){

        }
        public String getNome(){
            return this.nome;
        }
        public String setNome(String nome){
            return this.nome = nome;
        }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public LocalDate getDataNasc() {
        return dataNasc;
    }

    public void setDataNasc(LocalDate dataNasc) {
        this.dataNasc = dataNasc;
    }
}
