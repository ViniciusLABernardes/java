package conn;

import java.sql.Connection;
import java.sql.SQLException;

public class TesteConexao {
    public static void main(String[] args){
        try {
            Connection conexao = new ConnectionFactory().pegarConexao();
            System.out.println("conexao criada");
        }catch (Exception e){
            System.out.println("n foi possivel conectar: " + e.getMessage());

        }
    }


}
