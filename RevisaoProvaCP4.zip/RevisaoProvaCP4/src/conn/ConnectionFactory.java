package conn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory{
    public ConnectionFactory(){

    }
    private String url = "jdbc:h2:./banco/bancoDeDados;AUTO_SERVER=TRUE";
    private String user = "sa";
    private String senha = "";

    public Connection pegarConexao(){
        try {
            Connection conexao = DriverManager.getConnection(url, user, senha);
            return conexao;
        }catch (SQLException e){
            throw new RuntimeException(e);
        }

    }
}
