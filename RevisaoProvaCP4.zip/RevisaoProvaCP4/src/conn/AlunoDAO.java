package conn;

import dominio.Aluno;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

public class AlunoDAO {

    private Connection conexao;

    public AlunoDAO(){
        conexao = new ConnectionFactory().pegarConexao();
    }

    String insercaoSQL = "INSERT INTO TB_ALUNO(nome,cpf,data_nascimento) VALUES(?,?,?)";

    public void adicionarAluno(Aluno aluno){
        try{
            PreparedStatement preparandoInsercao = conexao.prepareStatement(insercaoSQL);
            preparandoInsercao.setString(1,aluno.getNome());
            preparandoInsercao.setString(2,aluno.getCpf());
            preparandoInsercao.setDate(3, Date.valueOf(aluno.getDataNasc()));
            preparandoInsercao.execute();
            preparandoInsercao.close();
            conexao.close();
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }
    public void fecharConexao(){
        try{
            conexao.close();
        }catch (SQLException e){
            System.out.println("falha ao fechar banco: " + e.getMessage());
        }
    }




}
