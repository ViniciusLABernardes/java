import conn.AlunoDAO;
import dominio.Aluno;

import java.time.LocalDate;

public class SistemaAlunos {
    public static void main(String[] args){

        Aluno aluno = new Aluno("jorge","123456789", LocalDate.of(2002,7,8));

        AlunoDAO alunoDAO = new AlunoDAO();

        alunoDAO.adicionarAluno(aluno);
    }
}
